from tkinter import *
from tkinter import scrolledtext
from datetime import datetime
root = Tk()
root.title("Smart College Assistant Chatbot")
root.geometry("700x650")
root.configure(bg="#dbefff")
user_name = ""
def chatbot_response(message):
    global user_name
    msg = message.lower()
    if "my name is" in msg:
        user_name = msg.replace("my name is", "").strip()
        return f"Hello {user_name.title()}! Welcome to Smart College Assistant."
    elif "hello" in msg or "hi" in msg:
        if user_name:
            return f"Hello {user_name.title()}! How can I help you today?"
        return "Hello! Welcome to our college."
    elif "course" in msg or "courses" in msg:
        return "We offer CSE, ECE, EEE, MBA, MCA, BCA and Civil Engineering."
    elif "admission" in msg:
        return "Admissions are currently open. Visit the admission block for details."
    elif "hostel" in msg:
        return "Separate hostel facilities are available for boys and girls."
    elif "placement" in msg:
        return "Top companies like TCS, Infosys and Wipro visit our campus."
    elif "library" in msg:
        return "The library is open from 9 AM to 6 PM."
    elif "canteen" in msg or "food" in msg:
        return "The college canteen provides breakfast, lunch and snacks."
    elif "time" in msg or "college timing" in msg:
        return "College timings are 9 AM to 4 PM."
    elif "contact" in msg:
        return "You can contact the office at 9876543210."
    elif "principal" in msg:
        return "Our principal is Dr. Ramesh Kumar."
    elif "date" in msg:
        today = datetime.now().strftime("%d-%m-%Y")
        return f"Today's date is {today}"
    elif "clock" in msg or "current time" in msg:
        current = datetime.now().strftime("%I:%M %p")
        return f"Current time is {current}"
    elif "thank" in msg:
        return "You are welcome!"
    elif "bye" in msg:
        if user_name:
            return f"Goodbye {user_name.title()}! Have a great day."
        return "Goodbye! Have a nice day."
    else:
        return "Sorry, I didn't understand. Please ask about admissions, courses, hostel, placements, or library."
def send_message():
    message = user_entry.get()
    if message.strip() == "":
        return
    chat_area.insert(END, "You : " + message + "\n")
    response = chatbot_response(message)
    chat_area.insert(END, "Bot : " + response + "\n\n")
    user_entry.delete(0, END)
    chat_area.yview(END)
title_label = Label(root,
                    text="SMART COLLEGE ASSISTANT CHATBOT",
                    font=("Arial", 18, "bold"),
                    bg="#004080",
                    fg="white",
                    pady=10)
title_label.pack(fill=X)
chat_area = scrolledtext.ScrolledText(root,
                                      wrap=WORD,
                                      width=70,
                                      height=25,
                                      font=("Arial", 12),
                                      bg="white",
                                      fg="black")
chat_area.pack(padx=10, pady=10)
chat_area.insert(END,
                 "Bot : Hello! I am your Smart College Assistant.\n"
                 "You can ask me about admissions, courses, hostel, placements and more.\n\n")
entry_frame = Frame(root, bg="#dbefff")
entry_frame.pack(pady=10)
user_entry = Entry(entry_frame,
                   width=45,
                   font=("Arial", 14))
user_entry.grid(row=0, column=0, padx=10)
send_button = Button(entry_frame,
                     text="Send",
                     font=("Arial", 12, "bold"),
                     bg="green",
                     fg="white",
                     width=10,
                     command=send_message)
send_button.grid(row=0, column=1)
exit_button = Button(root,
                     text="Exit",
                     font=("Arial", 12, "bold"),
                     bg="red",
                     fg="white",
                     width=10,
                     command=root.destroy)
exit_button.pack(pady=5)
root.bind('<Return>', lambda event: send_message())
root.mainloop()
