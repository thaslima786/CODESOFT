import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import pyttsx3
import random
engine = pyttsx3.init()
normal_captions = [
    "A beautiful scene captured in the image.",
    "A person enjoying a pleasant moment.",
    "An interesting picture with clear details."
]
funny_captions = [
    "This image deserves an Oscar!",
    "Looks like someone is having a great day.",
    "A masterpiece straight from the camera."
]
professional_captions = [
    "A professionally captured visual representation.",
    "An image showcasing remarkable composition.",
    "A high-quality photograph with excellent detail."
]
def upload_image():
    global img_label
    file_path = filedialog.askopenfilename(
        filetypes=[("Image Files", "*.jpg *.png *.jpeg")]
    )
    if file_path:
        image = Image.open(file_path)
        image = image.resize((350, 250))
        photo = ImageTk.PhotoImage(image)
        img_label.config(image=photo)
        img_label.image = photo
def generate_caption():
    style = style_var.get()
    if style == "Normal":
        caption = random.choice(normal_captions)
    elif style == "Funny":
        caption = random.choice(funny_captions)
    else:
        caption = random.choice(professional_captions)
    caption_label.config(text=caption)
def speak_caption():
    text = caption_label.cget("text")
    if text:
        engine.say(text)
        engine.runAndWait()
root = tk.Tk()
root.title("Smart Image Caption Generator")
root.geometry("700x600")
root.configure(bg="lightblue")
title = tk.Label(
    root,
    text="Smart Image Caption Generator",
    font=("Arial", 18, "bold"),
    bg="lightblue"
)
title.pack(pady=10)
img_label = tk.Label(root, bg="white")
img_label.pack(pady=10)

style_var = tk.StringVar()
style_var.set("Normal")

style_menu = tk.OptionMenu(
    root,
    style_var,
    "Normal",
    "Funny",
    "Professional"
)
style_menu.pack(pady=5)

upload_btn = tk.Button(
    root,
    text="Upload Image",
    command=upload_image,
    bg="green",
    fg="white"
)
upload_btn.pack(pady=5)

caption_btn = tk.Button(
    root,
    text="Generate Caption",
    command=generate_caption,
    bg="blue",
    fg="white"
)
caption_btn.pack(pady=5)

caption_label = tk.Label(
    root,
    text="Caption will appear here",
    font=("Arial", 14),
    bg="lightblue"
)
caption_label.pack(pady=20)

voice_btn = tk.Button(
    root,
    text="Speak Caption",
    command=speak_caption,
    bg="orange"
)
voice_btn.pack(pady=5)

root.mainloop()
