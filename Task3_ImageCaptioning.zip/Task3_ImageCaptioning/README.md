# Smart Image Caption Generator
A Python-based Image Captioning project developed using Tkinter.
## Features
- Upload Image
- Multiple Caption Styles
- Voice Output
- User-Friendly GUI
## Technologies
- Python
- Tkinter
- Pillow
- pyttsx3